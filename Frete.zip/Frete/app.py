from melhorEnvio import cotar_melhor_envio
from braspress import cotar_braspress
from frete import escolher_melhor_frete

def solicitar_cep(mensagem):
    while True:
        cep = input(mensagem).strip().replace("-", "")
        if cep.isdigit() and len(cep) == 8:
            return cep
        print("CEP inválido! Digite novamente (somente números).")

def solicitar_float(mensagem):
    while True:
        try:
            return float(input(mensagem).strip())
        except ValueError:
            print("Digite um número válido.")

def solicitar_int(mensagem):
    while True:
        try:
            return int(input(mensagem).strip())
        except ValueError:
            print("Digite um número inteiro válido.")

def executar_cotacao():
    peso = solicitar_float("Peso (kg): ")
    altura = solicitar_int("Altura (cm): ")
    largura = solicitar_int("Largura (cm): ")
    comprimento = solicitar_int("Comprimento (cm): ")
    cep_origem = solicitar_cep("Digite o CEP de origem: ")
    cep_destino = solicitar_cep("Digite o CEP de destino: ")

    prioridade = input("Prioridade ('mais_barato', 'mais_rapido', 'equilibrado'): ").strip()
    if prioridade not in ["mais_barato", "mais_rapido", "equilibrado"]:
        prioridade = "mais_barato"

    cotacoes = []

    melhor_envio_resultado = cotar_melhor_envio(peso, altura, largura, comprimento, cep_origem, cep_destino)
    for item in melhor_envio_resultado:
        cotacoes.append({
            "nome": str(item["name"]),
            "preco": float(item["price"]),
            "prazo": int(item["delivery_time"])
        })

    cotacoes.append(cotar_braspress(peso, altura, largura, comprimento, cep_origem, cep_destino))

    print("\nCotações disponíveis:")
    for c in cotacoes:
        print(f"- {c['nome']}: R${c['preco']} | Prazo: {c['prazo']} dias")

    melhor = escolher_melhor_frete(cotacoes, prioridade=prioridade)
    print(f"\n Melhor opção ({prioridade}):")
    print(f"{melhor['nome']} - R${melhor['preco']} - {melhor['prazo']} dias")

if __name__ == "__main__":
    executar_cotacao()