import random

def cotar_melhor_envio(peso, altura, largura, comprimento, cep_origem, cep_destino):
    volume = altura * largura * comprimento

    # Simulando 3 transportadoras do Melhor Envio
    transportadoras = ["Correios - PAC", "Correios - SEDEX", "Jadlog"]

    cotacoes = []
    for nome in transportadoras:
        preco = round(peso * 1.1 + volume * 0.0002 + random.uniform(10, 30), 2)
        prazo = random.randint(7, 20)
        cotacoes.append({
            "name": nome,
            "price": preco,
            "delivery_time": prazo
        })

    return cotacoes