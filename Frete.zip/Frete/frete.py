# frete.py
def escolher_melhor_frete(cotacoes, prioridade="mais_barato"):
    if prioridade == "mais_barato":
        return min(cotacoes, key=lambda x: x['preco'])
    elif prioridade == "mais_rapido":
        return min(cotacoes, key=lambda x: x['prazo'])
    else:  # equilíbrio
        return min(cotacoes, key=lambda x: x['preco'] * 0.6 + x['prazo'] * 0.4)
