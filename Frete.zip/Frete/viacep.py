# viacep.py
'''import requests

def consultar_cep(cep):
    """
    Consulta o CEP usando a API ViaCEP.
    Retorna um dicionário com os dados ou None se inválido.
    """
    cep = cep.strip().replace("-", "")
    if not (cep.isdigit() and len(cep) == 8):
        return None

    try:
        response = requests.get(f"https://viacep.com.br/ws/{cep}/json/", timeout=5)
        if response.status_code == 200:
            dados = response.json()
            if "erro" in dados:
                return None
            return dados
    except Exception as e:
        print(f"Erro na consulta do CEP: {e}")
    return None
'''