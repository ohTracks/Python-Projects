import random

def cotar_braspress(peso, altura, largura, comprimento, cep_origem, cep_destino):
    volume = altura * largura * comprimento

    preco = round(peso * 1.2 + volume * 0.0003 + random.uniform(10, 30), 2)
    prazo = prazo = random.randint(7, 20)
    return {
        "nome": "Braspress",
        "preco": round(preco, 2),
        "prazo": prazo
    }
