import json, os

CAMINHO = "estoqueMeias/dados/produtos.json"

def carregar_produtos():
    if not os.path.exists(CAMINHO):
        return {}
    with open(CAMINHO, "r") as f:
        return json.load(f)

def salvar_produtos(dados):
    with open(CAMINHO, "w") as f:
        json.dump(dados, f, indent=4)

def registrar_producao(modelo, quantidade):
    modelo = modelo.strip().lower()
    produtos = carregar_produtos()
    if modelo in produtos:
        produtos[modelo] += quantidade
    else:
        produtos[modelo] = quantidade
    salvar_produtos(produtos)
