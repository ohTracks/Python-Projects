import json, os

CAMINHO = "dados\produtos.json"

def carregar_produtos():
    if not os.path.exists(CAMINHO):
        return {}
    with open(CAMINHO, "r") as f:
        return json.load(f)

def salvar_produtos(dados):
    with open(CAMINHO, "w") as f:
        json.dump(dados, f, indent=4)

def registrar_producao(modelo, quantidade):
    modelo = modelo.strip().lower()
    produtos = carregar_produtos()
    if modelo in produtos:
        produtos[modelo] += quantidade
    else:
        produtos[modelo] = quantidade
    salvar_produtos(produtos)

def remover_produto(nome, quantidade):
    produtos = carregar_produtos()
    if nome in produtos:
        if produtos[nome] >= quantidade:
            produtos[nome] -= quantidade
            if produtos[nome] == 0:
                del produtos[nome]
            salvar_produtos(produtos)
            return True
        else:
            return False
    return False

