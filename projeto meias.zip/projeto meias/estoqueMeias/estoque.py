import json, os

CAMINHO = "estoqueMeias/dados/materias.json"

def carregar_materiais():
    if not os.path.exists(CAMINHO):
        return {}
    with open(CAMINHO, "r") as f:
        return json.load(f)

def salvar_materiais(dados):
    with open(CAMINHO, "w") as f:
        json.dump(dados, f, indent=4)

def adicionar_materia(nome, quantidade):
    nome = nome.strip().lower()
    dados = carregar_materiais()
    if nome in dados:
        dados[nome] += quantidade
    else:
        dados[nome] = quantidade
    salvar_materiais(dados)
