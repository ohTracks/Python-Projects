import tkinter as tk
from tkinter import messagebox
from estoque import adicionar_materia, carregar_materiais
from prod import registrar_producao, carregar_produtos

# LISTAS DE OPÇÕES
materiais_disponiveis = ["algodão", "elastano", "corante"]
modelos_meias = [
    "meia_branca_P", "meia_branca_M", "meia_branca_G",
    "meia_preta_P", "meia_preta_M", "meia_preta_G",
    "meia_colorida_P", "meia_colorida_M", "meia_colorida_G"
]

# Função: Adicionar matéria-prima
def adicionar_materia_ui():
    nome = escolha_materia.get().strip().lower()
    try:
        qtd = int(entrada_qtd.get())
        adicionar_materia(nome, qtd)
        messagebox.showinfo("Sucesso", f"{qtd}g de {nome} adicionados.")
        entrada_qtd.delete(0, tk.END)
    except ValueError:
        messagebox.showerror("Erro", "Digite uma quantidade válida.")

# Função: Registrar produção de meias
def registrar_producao_ui():
    modelo = escolha_modelo.get().strip().lower()
    try:
        qtd = int(entrada_qtd_modelo.get())
        registrar_producao(modelo, qtd)
        messagebox.showinfo("Sucesso", f"{qtd} unidades de {modelo} registradas.")
        entrada_qtd_modelo.delete(0, tk.END)
    except ValueError:
        messagebox.showerror("Erro", "Digite uma quantidade válida.")

# Mostrar estoque de matérias-primas
def mostrar_estoque_materia():
    materiais = carregar_materiais()
    texto = "\n".join([f"{nome}: {qtd}g" for nome, qtd in materiais.items()])
    messagebox.showinfo("Estoque de Matéria-Prima", texto or "Sem itens no estoque.")

# Mostrar estoque de produtos
def mostrar_estoque_produto():
    produtos = carregar_produtos()
    texto = "\n".join([f"{nome}: {qtd} unidades" for nome, qtd in produtos.items()])
    messagebox.showinfo("Estoque de Produtos", texto or "Sem produtos registrados.")

# Criar janela principal
janela = tk.Tk()
janela.title("Sistema de Estoque - Fábrica de Meias")
janela.geometry("400x550")

# Adicionar matéria-prima
tk.Label(janela, text="Escolha a matéria-prima:").pack()
escolha_materia = tk.StringVar(janela)
escolha_materia.set(materiais_disponiveis[0])
tk.OptionMenu(janela, escolha_materia, *materiais_disponiveis).pack()

tk.Label(janela, text="Quantidade (g):").pack()
entrada_qtd = tk.Entry(janela)
entrada_qtd.pack()

tk.Button(janela, text="Adicionar ao Estoque", command=adicionar_materia_ui).pack(pady=5)

# Registrar produção
tk.Label(janela, text="Escolha o modelo da meia:").pack(pady=(20, 0))
escolha_modelo = tk.StringVar(janela)
escolha_modelo.set(modelos_meias[0])
tk.OptionMenu(janela, escolha_modelo, *modelos_meias).pack()

tk.Label(janela, text="Quantidade Produzida:").pack()
entrada_qtd_modelo = tk.Entry(janela)
entrada_qtd_modelo.pack()

tk.Button(janela, text="Registrar Produção", command=registrar_producao_ui).pack(pady=5)

# Visualizar estoques
tk.Button(janela, text="Ver Estoque de Matéria-prima", command=mostrar_estoque_materia).pack(pady=10)
tk.Button(janela, text="Ver Estoque de Produtos", command=mostrar_estoque_produto).pack()

janela.mainloop()
