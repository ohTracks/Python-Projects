import tkinter as tk
from tkinter import messagebox
from estoque import adicionar_materia, carregar_materiais
from prod import registrar_producao, carregar_produtos

# LISTAS DE OPÇÕES
materiais_disponiveis = ["algodão", "elastano", "corante"]
modelos_meias = [
    "meia_branca_P", "meia_branca_M", "meia_branca_G",
    "meia_preta_P", "meia_preta_M", "meia_preta_G",
    "meia_colorida_P", "meia_colorida_M", "meia_colorida_G"
]

# Função: Adicionar matéria-prima
def adicionar_materia_ui():
    nome = escolha_materia.get().strip().lower()
    try:
        qtd = int(entrada_qtd.get())
        adicionar_materia(nome, qtd)
        messagebox.showinfo("Sucesso", f"{qtd}Kg de {nome} adicionados.")
        entrada_qtd.delete(0, tk.END)
    except ValueError:
        messagebox.showerror("Erro", "Digite uma quantidade válida.")

# Função: Registrar produção de meias
def registrar_producao_ui():
    modelo = escolha_modelo.get().strip().lower()
    try:
        qtd = int(entrada_qtd_modelo.get())
        registrar_producao(modelo, qtd)
        messagebox.showinfo("Sucesso", f"{qtd} unidades de {modelo} registradas.")
        entrada_qtd_modelo.delete(0, tk.END)
    except ValueError:
        messagebox.showerror("Erro", "Digite uma quantidade válida.")

# Mostrar estoque de matérias-primas
def mostrar_estoque_materia():

    materiais = carregar_materiais()

    # Criar janela nova
    win = tk.Toplevel(janela)
    win.title("Estoque de Matéria-Prima")
    win.geometry("300x300")
    win.configure(bg="#f5f5f5")

    tk.Label(win, text="📦 Estoque de Matéria-Prima", 
    bg="#f5f5f5", fg="#880319", font=("Arial", 14)).pack(pady=10)

    if materiais:
        for nome, qtd in materiais.items():
            tk.Label(win, text=f"{nome}: {qtd}Kg", 
            bg="#f5f5f5", fg="#333", font=("Arial", 12)).pack(anchor="w", padx=20)
    else:
        tk.Label(win, text="Sem itens no estoque.", 
        bg="#f5f5f5", fg="#333", font=("Arial", 12)).pack()

    # Botão para fechar
    tk.Button(win, text="Fechar", command=win.destroy,
    bg="#880319", fg="white", activebackground="#630616", activeforeground="white",
    font=("Arial", 11), padx=10, pady=5).pack(pady=15)


# Mostrar estoque de produtos
def mostrar_estoque_produto():

    produtos = carregar_produtos()

    win = tk.Toplevel(janela)
    win.title("Estoque de Produtos")
    win.geometry("500x600")
    win.configure(bg="#f5f5f5")

    tk.Label(win, text="🧦 Estoque de Produtos", 
            bg="#f5f5f5", fg="#880319", font=("Arial", 14)).pack(pady=10)

    if produtos:
        for nome, qtd in produtos.items():
            tk.Label(win, text=f"{nome}: {qtd} unidades", 
            bg="#f5f5f5", fg="#333", font=("Arial", 12)).pack(anchor="w", padx=20)
    else:
        tk.Label(win, text="Sem produtos registrados.", 
        bg="#f5f5f5", fg="#333", font=("Arial", 12)).pack()

    tk.Button(win, text="Fechar", command=win.destroy,
    bg="#880319", fg="white", activebackground="#630616", activeforeground="white",
    font=("Arial", 11), padx=10, pady=5).pack(pady=15)


# Criar janela principal
janela = tk.Tk()
janela.title("Sistema de Estoque - Fábrica de Meias")
janela.geometry("600x750")
janela.configure(bg="#f5f5f5")  # fundo geral

# Adicionar matéria-prima
tk.Label(janela, text="Escolha a matéria-prima:", bg="#f5f5f5", fg="#880319", font=("Arial", 12)).pack()
escolha_materia = tk.StringVar(janela)
escolha_materia.set(materiais_disponiveis[0])
op_materia = tk.OptionMenu(janela, escolha_materia, *materiais_disponiveis)
op_materia.config(bg="#880319", fg="white", activebackground="#630616", activeforeground="white", font=("Arial", 11))
op_materia.pack()

tk.Label(janela, text="Quantidade (Kg):", bg="#f5f5f5", fg="#880319", font=("Arial", 12)).pack()
entrada_qtd = tk.Entry(janela, font=("Arial", 11))
entrada_qtd.pack()

tk.Button(janela, text="Adicionar ao Estoque", command=adicionar_materia_ui,
        bg="#880319", fg="white", activebackground="#630616", activeforeground="white",
        font=("Arial", 12), padx=10, pady=5).pack(pady=5)

# Registrar produção
tk.Label(janela, text="Escolha o modelo da meia:", bg="#f5f5f5", fg="#880319", font=("Arial", 12)).pack(pady=(20, 0))
escolha_modelo = tk.StringVar(janela)
escolha_modelo.set(modelos_meias[0])
op_modelo = tk.OptionMenu(janela, escolha_modelo, *modelos_meias)
op_modelo.config(bg="#880319", fg="white", activebackground="#630616", activeforeground="white", font=("Arial", 11))
op_modelo.pack()

tk.Label(janela, text="Quantidade Produzida:", bg="#f5f5f5", fg="#880319", font=("Arial", 12)).pack()
entrada_qtd_modelo = tk.Entry(janela, font=("Arial", 11))
entrada_qtd_modelo.pack()

tk.Button(janela, text="Registrar Produção", command=registrar_producao_ui,
        bg="#880319", fg="white", activebackground="#630616", activeforeground="white",
        font=("Arial", 12), padx=10, pady=5).pack(pady=5)

# Visualizar estoques
tk.Button(janela, text="Ver Estoque de Matéria-prima", command=mostrar_estoque_materia,
        bg="#880319", fg="white", activebackground="#630616", activeforeground="white",
        font=("Arial", 12), padx=10, pady=5).pack(pady=10)

tk.Button(janela, text="Ver Estoque de Produtos", command=mostrar_estoque_produto,
        bg="#880319", fg="white", activebackground="#630616", activeforeground="white",
        font=("Arial", 12), padx=10, pady=5).pack()

janela.mainloop()
